package gui;
public class Test_File
{
	public String testString;
	private int testInt;

	double testDouble;

	
	public double testDouble2;

	private 
			static int 
testStatInt;
}
